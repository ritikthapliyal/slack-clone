const AWS = require('aws-sdk')
const DynamoDB = new AWS.DynamoDB.DocumentClient()
const nodemailer = require("nodemailer")
const {google} = require("googleapis")
const getEmailTemplate = require('./email_template')


exports.handler = async (event) => {
  
  console.log(event)
  
  if(event.path === '/send_mail'){
    
    const {user_details, invite_emails} = JSON.parse(event.body)
    
    console.log(invite_emails)

    const oAuth2Client = new google.auth.OAuth2(process.env.CLIENT_ID,process.env.CLIENT_SECRET,process.env.REDIRECT_URI)
    oAuth2Client.setCredentials({ refresh_token : process.env.REFRESH_TOKEN})

    try{

        const accessToken = await oAuth2Client.getAccessToken()

        let transporter = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
                type: 'OAuth2',
                user: process.env.EMAIL,
                // pass: process.env.PASS,
                clientId: process.env.CLIENT_ID,
                clientSecret: process.env.CLIENT_SECRET,
                refreshToken: process.env.REFRESH_TOKEN,
                accessToken : accessToken
            },
        })
        
        const emailsPromises = invite_emails.map((email) => {
            
            const mailOptions = {
                from: process.env.EMAIL,
                to: email,
                subject: 'Workspace Invitation',
                html: getEmailTemplate(user_details.name,user_details.workspace_name)
            }
            
            return transporter.sendMail(mailOptions)
            
        })
        
        await Promise.all(emailsPromises)
          
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Emails sent successfully' }),
        }
      } catch (error) {
        console.log(error)
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to send emails' }),
        }
      }
  }
  
  const response = {
    statusCode: 200,
    body: JSON.stringify('Hello from Lambda!'),
  }
  
  return response;
}